package Asignaturas;

public class Matematica {

    public Matematica() {

    }

    public Matematica(String Tema) {

    }

    public void MatematicaPrimeroM(int OpcionTemas) {
        String TemaPrimero = ""; //Leer Archivo LenguajePrimero y mostrar el contenido

    }

    public void MatematicaSegundoM(int OpcionTema) {
        String TemaSegundo = ""; //Leer Archivo LenguajeSegundo y mostrar el contenido
    }

    public void MatematicaTerceroM(int OpcionTema) {
        String TemaTercero = ""; //Leer Archivo Terceroo y mostrar el contenido;
    }

    public void MatematicaCuartoM(int OpcionTema) {
        String TemaCuarto = ""; //Leer Archivo Cuarto y mostrar el contenido;
    }

}
