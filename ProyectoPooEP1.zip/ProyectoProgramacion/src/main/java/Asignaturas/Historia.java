package Asignaturas;
public class Historia {

    public Historia() {

    }

    public void HistoriaPrimeroM(int OpcionTema) {
        //Leer Archivo LenguajePrimero y mostrar el contenido

    }

    public void HistoriaSegundoM(int OpcionTema) {
         //Leer Archivo LenguajeSegundo y mostrar el contenido
    }

    public void HistoriaTerceroM(int OpcionTema) {
         //Leer Archivo Terceroo y mostrar el contenido;
    }

    public void HistoriaCuartoM(int OpcionTema) {
        //Leer Archivo Cuarto y mostrar el contenido;
    }
}
