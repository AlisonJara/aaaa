package Asignaturas;

public class Ciencias {

    public Ciencias() {

    }

    public void CienciasPrimeroM(int OpcionTema) {
        String TemaPrimero = ""; //Leer Archivo LenguajePrimero y mostrar el contenido
    }

    public void CienciasSegundoM(int OpcionTema) {
        String TemaSegundo = ""; //Leer Archivo LenguajeSegundo y mostrar el contenido
    }

    public void CienciasTerceroM(int OpcionTema) {
        String TemaTercero = ""; //Leer Archivo Terceroo y mostrar el contenido;
    }

    public void CienciasCuartoM(int OpcionTema) {
        String TemaCuarto = ""; //Leer Archivo Cuarto y mostrar el contenido;
    }

}
