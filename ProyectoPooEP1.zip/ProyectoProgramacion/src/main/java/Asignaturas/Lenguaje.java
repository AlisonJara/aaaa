package Asignaturas;

import java.util.ArrayList;

public class Lenguaje {

    public Lenguaje() {

    }

    public void LenguajePrimeroM(int OpcionTemas) {
        String TemaPrimero = ""; //Leer Archivo LenguajePrimero y mostrar el contenido

    }

    public void LenguajeSegundoM(int OpcionTema) {
        String TemaSegundo = ""; //Leer Archivo LenguajeSegundo y mostrar el contenido
    }

    public void LenguajeTerceroM(int OpcionTema) {
        String TemaTercero = ""; //Leer Archivo Terceroo y mostrar el contenido;
    }

    public void LenguajeCuartoM(int OpcionTema) {
        String TemaCuarto = ""; //Leer Archivo Cuarto y mostrar el contenido;
    }
}
