package ContenidosCursos;

public class ContenidoTerceroM {

    public void Lenguaje() {
        //Leer Archivo materia LenguajeTerceroMedio y mostrarlo
        //Leer Archivo Ejercicios y mostrarlos
        //hacer quizz(a futuro)
    }

    public void Matematicas() {
        //Leer Archivo materia MatematicaTerceroMedio y mostrarlo
        //Leer Archivo Ejercicios y mostrarlos
        //hacer quizz(a futuro)
    }

    public void Historia() {
        //Leer Archivo materia HistoriaTerceroMedioy mostrarlo
        //Leer Archivo Ejercicios y mostrarlos
        //hacer quizz(a futuro)
    }

    public void Ciencias() {
        //Leer Archivo materia CienciasTerceroMedio y mostrarlo
        //Leer Archivo Ejercicios y mostrarlos
        //hacer quizz(a futuro)
    }
}
