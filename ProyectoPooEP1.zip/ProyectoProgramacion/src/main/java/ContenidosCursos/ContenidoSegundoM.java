package ContenidosCursos;

public class ContenidoSegundoM {

    public void Lenguaje() {
        //Leer Archivo materia LenguajeSegundoMedio y mostrarlo
        //Leer Archivo Ejercicios y mostrarlos
        //hacer quizz(a futuro)
    }

    public void Matematicas() {
        //Leer Archivo materia MatematicaSegundoMedio y mostrarlo
    }

    public void Historia() {
        //Leer Archivo materia HistoriaSegundoMedioy mostrarlo
        //Leer Archivo Ejercicios y mostrarlos
        //hacer quizz(a futuro)
    }

    public void Ciencias() {
        //Leer Archivo materia CienciasSegundoMedio y mostrarlo
        //Leer Archivo Ejercicios y mostrarlos
        //hacer quizz(a futuro)
    }
}
