package ContenidosCursos;

import Asignaturas.Lenguaje;
import Asignaturas.Matematica;
import Asignaturas.Historia;
import Asignaturas.Ciencias;
import java.util.Scanner;

public class ContenidoPrimeroM {

    Lenguaje Lenguaje = new Lenguaje();
    Matematica Matematica = new Matematica();
    Historia Historia = new Historia();
    Ciencias Ciencias = new Ciencias();
    int OpcionTemas;
    Scanner Entrada = new Scanner(System.in);

    public ContenidoPrimeroM() {

    }

    public void Lenguaje() {

        System.out.println("1.- narrativa y lírica");
        System.out.println("2.- género dramático");
        System.out.println("3.- medios de comunicación");
        System.out.println("0.- Salir");
        System.out.println("Elija la materia que desea reforzar");
        OpcionTemas = Entrada.nextInt();

        Lenguaje.LenguajePrimeroM(OpcionTemas);

    }

    public void Matematicas() {
        System.out.println("1.- ");
        System.out.println("2.- ");
        System.out.println("3.- ");
        System.out.println("0.- Salir");
        System.out.println("Elija la materia que desea reforzar");
        OpcionTemas = Entrada.nextInt();

        Matematica.MatematicaPrimeroM(OpcionTemas);
    }

    public void Historia() {
        System.out.println("1.- ");
        System.out.println("2.- ");
        System.out.println("3.- ");
        System.out.println("0.- Salir");
        System.out.println("Elija la materia que desea reforzar");
        OpcionTemas = Entrada.nextInt();

        Historia.HistoriaPrimeroM(OpcionTemas);
    }

    public void Ciencias() {
        System.out.println("1.- ");
        System.out.println("2.- ");
        System.out.println("3.- ");
        System.out.println("0.- Salir");
        System.out.println("Elija la materia que desea reforzar");
        OpcionTemas = Entrada.nextInt();

        Ciencias.CienciasPrimeroM(OpcionTemas);
    }

}
