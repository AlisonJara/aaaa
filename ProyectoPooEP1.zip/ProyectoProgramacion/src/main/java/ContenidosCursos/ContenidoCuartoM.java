package ContenidosCursos;

public class ContenidoCuartoM {

    public void Lenguaje() {
        //Leer Archivo materia LenguajeCuartoMedio y mostrarlo
        //Leer Archivo Ejercicios y mostrarlos
        //hacer quizz(a futuro)
    }

    public void Matematicas() {
        //Leer Archivo materia MatematicaCuartoMedio y mostrarlo
        //Leer Archivo Ejercicios y mostrarlos
        //hacer quizz(a futuro)
    }

    public void Historia() {
        //Leer Archivo materia HistoriaCuartoMedioy mostrarlo
        //Leer Archivo Ejercicios y mostrarlos
        //hacer quizz(a futuro)
    }

    public void Ciencias() {
        //Leer Archivo materia CienciasCuartoMedio y mostrarlo
        //Leer Archivo Ejercicios y mostrarlos
        //hacer quizz(a futuro)
    }
}
